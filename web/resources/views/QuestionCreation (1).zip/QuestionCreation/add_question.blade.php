@extends('layouts.adminnav')

@section('content')

<style>
    input[type=checkbox] {
        display: inline-block;

    }

    .no-arrow {
        -moz-appearance: textfield;
    }

    .no-arrow::-webkit-inner-spin-button {
        display: none;
    }

    .no-arrow::-webkit-outer-spin-button,
    .no-arrow::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* body{
        background-color: white !important;
    } */
    .nav-tabs {
        background-color: #0068a7 !important;
        border-radius: 29px !important;
        padding: 1px !important;

    }

    .nav-item.active {
        background-color: #0e2381 !important;
        border-radius: 31px !important;
        height: 100% !important;
    }

    .nav-link.active {
        background-color: #0e2381 !important;
        border-radius: 31px !important;
        height: 100% !important;
    }

    .nav-justified {
        display: flex !important;
        align-items: center !important;
    }

    hr {
        border-top: 1px solid #6c757d !important;
    }

    .dateformat {
        height: 41px;
        padding: 8px 10px !important;
        width: 100%;
        border-radius: 5px !important;
        border-color: #bec4d0 !important;
        box-shadow: 2px 2px 4px rgb(0 0 0 / 15%);
        border-style: outset;
    }

    h4 {
        text-align: center;
    }

    .question {
        background-color: white;
        border-radius: 12px !important;
        margin-top: 2rem;
    }

    .question label {
        text-align: center;
    }

    .questionnaire {
        text-align: center;
    }

    .btn-success {
        margin: auto;
    }
</style>
<div class="main-content">

    <div class="section-body mt-0">
        <h4> Questionnaire Creation </h4>



        <div class="card question">
            <div class="row" style="margin-bottom: 15px;margin-top: 20px;">
                @foreach($questionnaire_list as $data)
                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <label class="control-label">Questionnaire Name</label>
                        <select class="form-control" name="questionnaire_id" id="questionnaire_id">
                            <!-- <option value="">select Questionnaire</option> -->

                            <option value="{{$data['questionnaire_id']}}">{{$data['questionnaire_name']}}</option>

                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <label class="control-label">Description</label>
                        <textarea class="form-control" type="text" id="discription" name="discription" placeholder="" autocomplete="off">{{$data['questionnaire_description']}}</textarea>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <div>
                            <label class="control-label">No.Of.Questions</label><br>
                        </div>
                        <div style="display: flex;">
                            <input class="form-control" type="text" value="{{$data['question_count']}}" style="width:40%" readonly />
                            <p style="width:10%"> Of </p>
                            <input class="form-control" type="number" id="no_of_ques" name="no_of_ques" value="{{$data['no_questions']}}" style="width:50%" autocomplete="off">
                        </div>
                    </div>
                </div>
                <input type="hidden" id="questionnaire_details_id" name="questionnaire_details_id" value="{{$data['questionnaire_details_id']}}">
                <button type="button" class="btn btn-success" id="saveButton">Update</button>
                @endforeach
            </div>
        </div>


        @if($questionnaire_list[0]['question_count'] != $questionnaire_list[0]['no_questions'])
        <form action="{{ route('question_creation.store') }}" id="add_Question" method="POST">
            {{ csrf_field() }}

            <div class="card question" id="next-section">
                <div class="row" style="margin-bottom: 15px;margin-top: 20px;">

                    <div class="col-md-6">
                        <div class="form-group questionnaire">
                            <label class="control-label">Question type</label>
                            <select class="form-control" name="field_type_id" id="field_type_id" onChange="typeChange()">
                                <option value="">select Question type</option>
                                @foreach($field_types as $data)
                                <option value="{{$data['questionnaire_field_types_id']}}">{{$data['questionnaire_field_type']}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group questionnaire">
                            <label class="control-label">Questions</label>
                            <input class="form-control" type="text" id="field_question" name="field_question" autocomplete="off">
                        </div>
                    </div>
                    <input type="hidden" name="client_data" value="{{$questionnaire_list[0]['questionnaire_details_id']}}">
                    <div class="col-4" style="display: none;" id="option">
                        <div class="form-group">
                            <label>Option</label>
                            <div class="multi-field-wrapper">
                                <div class="multi-fields">
                                    <div class="multi-field" style="display: flex;margin-bottom: 5px;">
                                        <input type="text" class="form-control" name="options_questions[]" id="options_question[]">
                                        <button class="remove-field btn btn-danger pull-right" id="remove-f" type='button'>X </button>
                                        <!-- <button class="add-field btn btn-danger pull-right" id="" type='button'>+ </button> -->
                                        &nbsp;
                                    </div>
                                </div>
                                <!-- <button class="add-field btn btn-danger" id="" type='button'>+ </button> -->
                                <button type="button" class="add-field btn btn-success">Add Option</button>
                            </div>
                        </div>
                    </div>
                    <div class="w-100"></div>

                    <div class="row" style="display: none;" id="sub_questions">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Sub Question</label>
                                <div class="multi-field-wrapper">
                                    <div class="multi-fields">
                                        <div class="multi-field" style="display: flex;margin-bottom: 5px;">

                                            <input type="text" class="form-control" name="sub_question[]" id="sub_question[]">
                                            <button class="remove-field btn btn-danger pull-right" id="remove-f" type='button'>X </button>
                                            <!-- <button class="add-field btn btn-danger pull-right" id="" type='button'>+ </button> -->
                                            &nbsp;
                                        </div>
                                    </div>
                                    <button type="button" class="add-field btn btn-success">Add Question</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-6">
                            <div class="form-group">
                                <label>Option</label>
                                <div class="multi-field-wrapper">
                                    <div class="multi-fields">
                                        <div class="multi-field" style="display: flex;margin-bottom: 5px;">

                                            <input type="text" class="form-control" name="sub_options[]" id="sub_options[]">
                                            <button class="remove-field btn btn-danger pull-right" id="remove-f" type='button'>X </button>
                                            <!-- <button class="add-field btn btn-danger pull-right" id="" type='button'>+ </button> -->
                                            &nbsp;
                                        </div>
                                    </div>
                                    <button type="button" class="add-field btn btn-success">Add Option</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="w-100"></div>
                    @if((($questionnaire_list[0]['question_count'])+1) == $questionnaire_list[0]['no_questions'])
                    <input type="text" name="status" value="submit">
                    <a type="button" onclick="submit()" id="submitbutton" class="btn btn-success" title="submit">Submit</a>
                    @else
                    <input type="text" name="status" value="save">
                    <a type="button" onclick="submit()" id="submitbutton" class="btn btn-success" title="submit">Save</a>
                    @endif
                </div>
            </div>

            </section>
        </form>
        @endif
        @if($question_details !=[] )
        <div class="card question" id="list_section">
            <div class="card-body">
                <div class="table-wrapper">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="length5">
                            <thead>
                                <tr>
                                    <th>Sl.No</th>
                                    <th>Question</th>
                                    <th width="20%">Action</th>
                                    <th>Active Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($question_details as $data)
                                <tr>
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$data['question']}}</td>
                                    <td>
                                        <a class="btn btn-link" onclick="edit_question('{{$data['question_details_id']}}')" title="Edit" data-toggle="modal" data-target="#editmodulemodal{{$data['question_details_id']}}" style="color:darkblue"><i class="fas fa-pencil-alt"></i></a>
                                        @csrf
                                        <input type="hidden" name="delete_id" id="<?php echo $data['question_details_id']; ?>" value="{{ route('question_creation.data_delete', $data['question_details_id']) }}">
                                        <a class="btn btn-link" title="Delete" onclick="return myFunction(<?php echo $data['question_details_id']; ?>);" class="btn btn-link"><i class="far fa-trash-alt"></i></a>
                                    </td>
                                    <td style="text-align: center;">
                                        <label class="switch " data-bs-toggle="tooltip" data-bs-placement="top" title="Enable / Disable">
                                            <input type="hidden" name="toggle_id" value="{{$data['question_details_id']}}">
                                            <input type="checkbox" class="toggle_status" onclick="functiontoggle('{{$data['question_details_id']}}')" id="is_active{{$data['question_details_id']}}" name="is_active" @if($data['enable_flag']=='1' ) checked @endif>
                                            <span class="slider round"></span>
                                        </label>

                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>
@include('QuestionCreation.edit')
<script>
    function edit_question(id) {
        edit_question_id = id;

        $.ajax({
            url: '{{ url('/question_creation/get_options') }}',
            type: "POST",
            data: {
                _token: '{{csrf_token()}}',
                edit_question_id: edit_question_id,
            },

            success: function(data) {

                if (data == 3 || data == 4 || data == 5) {
                    $('#edit_option' + id).show();
                } else if (data == 6 || data == 7) {
                    $('#edit_option' + id).hide();
                    $('#edit_sub_questions' + id).show();
                } else {
                    $('#edit_option' + id).hide();
                }
            },
            error: function(data) {
                console.log(data);
            }
        });
    }
</script>
<script>
    $("#saveButton").click(function(event) {
        event.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var questionnaire_id = document.getElementById("questionnaire_id").value;
        if (questionnaire_id == null || questionnaire_id == "") {
            swal("Please Select Questionnaire Name: ", "", "error");
            return false;
        }

        var discription = document.getElementById("discription").value;
        if (discription == null || discription == '') {
            swal("Please Description", "", "error");
            return false;
        }

        var no_of_ques = document.getElementById("no_of_ques").value;
        if (no_of_ques == '' || no_of_ques == null) {
            swal("Please Enter No Of Questions", "", "error");
            return false;
        }

        var questionnaire_details_id = document.getElementById("questionnaire_details_id").value;

        $('#saveButton').prop('disabled', true);

        $.ajax({
            url: '{{ url('/question_creation/question_update') }}',
            type: "POST",
            data: {
                _token: '{{csrf_token()}}',
                questionnaire_id: questionnaire_id,
                discription: discription,
                no_of_ques: no_of_ques,
                questionnaire_details_id: questionnaire_details_id
            },

            success: function(data) {
                window.location.href = "/question_creation/add_questions/" + data;
            },
            error: function(data) {
                swal({
                    title: "Error",
                    text: data,
                    type: "error",
                    confirmButtonColor: '#e73131',
                    confirmButtonText: 'OK',
                });

            }
        });

    });
</script>
<script>
    function newsection() {
        document.getElementById('next-section').style.display = "block";

    }
</script>
<script type="text/javascript">
    $('.multi-field-wrapper').each(function() {
        var $wrapper = $('.multi-fields', this);
        $(".add-field", $(this)).click(function(e) {
            $('.multi-field:first-child', $wrapper).clone(true).appendTo($wrapper).find('input').val('').focus();
        });
        $('.multi-field .remove-field', $wrapper).click(function() {
            if ($('.multi-field', $wrapper).length > 2)
                $(this).parent('.multi-field').remove();
            else swal("Required Two Option", "", "error");
        });
    });
</script>

<script type="text/javascript">
    function typeChange() {
        var fieldtype = $('#field_type_id').val();

        if (fieldtype == 3 || fieldtype == 4 || fieldtype == 5) {
            $('#option').show();
        } else if (fieldtype == 6 || fieldtype == 7) {
            $('#option').hide();
            $('#sub_questions').show();
        } else {
            $('#option').hide();
        }
    }
</script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
<script>
    function submit() {

        var fieldtype = $('#field_type_id').val();
        // alert(fieldtype);
        if (fieldtype == null || fieldtype == "") {
            swal("Please Select Question Type", "", "error");
            return false;
        }
        var field_question = $('#field_question').val();
        if (field_question == null || field_question == "") {
            swal("Please Enter Question", "", "error");
            return false;
        }

        if (fieldtype == 3 || fieldtype == 4 || fieldtype == 5) {

            var que = document.getElementsByName('options_questions[]');
            var QueLength = que.length;

            if (QueLength < 2) {
                swal("Required Two Option!", "", "error");
                return false;
            }
            for (i = 0; i < QueLength; i++) {
                if (que[i].value == "") {
                    swal("Please Fill Option Field!", "", "error");
                    return false;
                }
            }

        } else if (fieldtype == 6 || fieldtype == 7) {

            var Subque = document.getElementsByName('sub_question[]');
            var SubLength = Subque.length;

            if (SubLength < 2) {
                swal("Required Two Question!", "", "error");
                return false;
            }
            for (i = 0; i < SubLength; i++) {
                if (Subque[i].value == "") {
                    swal("Please Fill Question Field!", "", "error");
                    return false;
                }
            }

            var que = document.getElementsByName('sub_options[]');
            var QueLength = que.length;

            if (QueLength < 2) {
                swal("Required Two Option!", "", "error");
                return false;
            }
            for (i = 0; i < QueLength; i++) {
                if (que[i].value == "") {
                    swal("Please Fill Option Field!", "", "error");
                    return false;
                }
            }

        }
        // alert('End');
        document.getElementById('add_Question').submit();
    }
</script>
<script type="application/javascript">
    function myFunction(id) {
        swal({
                title: "Confirmation For Delete ?",
                text: "Are You Sure to delete this data.",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#DD6B55',
                confirmButtonText: 'Yes, I am sure!',
                cancelButtonText: "No, cancel it!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {

                if (isConfirm) {
                    swal("Deleted!", "Data Deleted successfully!", "success");
                    var url = $('#' + id).val();
                    window.location.href = url;
                } else {
                    swal("Cancelled", "Your file is safe :)", "error");
                    e.preventDefault();
                }
            });
    }
</script>
<script>
     function functiontoggle(id) {
    // alert(id);
    if ($('#is_active' + id).prop('checked')) {
      var is_active = '1';
    } else {
      var is_active = '0';
    }
    var f_id = id;

    $.ajax({
      url: "{{ route('questionnaire.update_toggle') }}",
      type: 'POST',
      data: {
        is_active: is_active,
        f_id: f_id,
        _token: '{{csrf_token()}}'
      },
      error: function() {
        alert('Something is wrong');
      },
      success: function(data) {

        var data_convert = $.parseJSON(data);

        // console.log(data_convert.Data);
        if (data_convert.Data == 0) {
          swal({
            title: "Success",
            text: "Question Deactivated",
            type: "success"
          }, );
        } else {
          swal({
            title: "Success",
            text: "Question Activated",
            type: "success"
          }, );
        }

      }


    });
  }
</script>
@endsection