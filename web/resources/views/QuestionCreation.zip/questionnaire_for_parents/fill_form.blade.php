@extends('layouts.adminnav')

@section('content')
<style>
    @charset "UTF-8";

    body {
        font-family: "Open Sans";
    }

    .stepper-horizontal {
        display: table;
        width: 100%;
        margin: 0 auto;
    }

    .stepper-horizontal .step {
        display: table-cell;
        position: relative;
        padding: 1.5rem;
        z-index: 2;
        width: 25%;
    }

    .stepper-horizontal .step:last-child .step-bar-left,
    .stepper-horizontal .step:last-child .step-bar-right {
        display: none;
    }

    .stepper-horizontal .step .step-circle {
        width: 2rem;
        height: 2rem;
        margin: 0 auto;
        border-radius: 50%;
        text-align: center;
        line-height: 1.75rem;
        font-size: 1rem;
        font-weight: 600;
        z-index: 2;
        border: 2px solid #d9e2ec;
    }

    .stepper-horizontal .step.done .step-circle {
        background-color: #199473;
        border: 2px solid #199473;
        color: #ffffff;
    }

    .stepper-horizontal .step.done .step-circle:before {
        font-family: "FontAwesome";
        font-weight: 100;
        content: "";
    }

    .stepper-horizontal .step.done .step-circle * {
        display: none;
    }

    .stepper-horizontal .step.done .step-title {
        color: #102a43;
    }

    .stepper-horizontal .step.editing .step-circle {
        background: #ffffff;
        border-color: #199473;
        color: #199473;
    }

    .stepper-horizontal .step.editing .step-title {
        color: #199473;
        text-decoration: underline;
    }

    .stepper-horizontal .step .step-title {
        margin-top: 1rem;
        font-size: 1rem;
        font-weight: 600;
    }

    .stepper-horizontal .step .step-title,
    .stepper-horizontal .step .step-optional {
        text-align: center;
        color: #829ab1;
    }

    .stepper-horizontal .step .step-optional {
        font-size: 0.75rem;
        font-style: italic;
        color: #9fb3c8;
    }

    .stepper-horizontal .step .step-bar-left,
    .stepper-horizontal .step .step-bar-right {
        position: absolute;
        top: calc(2rem + 5px);
        height: 5px;
        background-color: #d9e2ec;
        border: solid #d9e2ec;
        border-width: 2px 0;
    }

    .stepper-horizontal .step .step-bar-left {
        width: calc(100% - 2rem);
        left: 50%;
        margin-left: 1rem;
        z-index: -1;
    }

    .stepper-horizontal .step .step-bar-right {
        width: 0;
        left: 50%;
        margin-left: 1rem;
        z-index: -1;
        transition: width 500ms ease-in-out;
    }

    .stepper-horizontal .step.done .step-bar-right {
        background-color: #199473;
        border-color: #199473;
        z-index: 3;
        width: calc(100% - 2rem);
    }
</style>
<style>
    .q_lable {
        padding-left: 3% !important;
    }
</style>
<style>
    .tab {
        overflow: hidden;
        border: 1px solid #f37020;
        background-color: #d4d0cf;
        border-radius: 36px;
        /* justify-content: center; */
        width: fit-content;
        margin: auto;
        text-align: center;

    }

    /* Style the buttons inside the tab */
    .tab button {
        background-color: #d4d0cf;
        /* float: left; */
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 4.1rem;
        transition: 0.3s;
        font-size: 20px;
        border-radius: 36px;
    }

    /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #f37020;
    }

    /* Create an active/current tablink class */
    .tab button.active {
        background-color: #f37020;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
    }
</style>
<style>
    .card_design {
        background-color: white;
        border-radius: 12px !important;
        margin-top: 2rem;
    }

    .card_design label {
        text-align: center;
    }
</style>
<style>
    .current {
        color: green;
    }

    #pagin li {
        display: inline-block;
    }

    .prev {
        cursor: pointer;
    }

    .next {
        cursor: pointer;
    }

    .last {
        cursor: pointer;
        margin-left: 5px;
    }

    .first {
        cursor: pointer;
        margin-right: 5px;
    }

    .table_content {
        width: 100%;
        border-collapse: collapse;
    }

    .table_content td,
    .table_content th {
        /* padding: 12px 15px; */
        text-align: center;
        font-size: 16px;
    }
</style>
<div class="main-content">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-md-12">
            <div class="" style="height:100%;">
                <div id="content">
                    <input type="hidden" id="questionnaireID" value="15">

                    <div class="stepper-horizontal" id="stepper1">
                        <div class="step editing">
                            <div class="step-circle"><span>1</span></div>
                            <div class="step-bar-left"></div>
                            <div class="step-bar-right"></div>
                        </div>
                        <div class="step">
                            <div class="step-circle"><span>2</span></div>
                            <div class="step-bar-left"></div>
                            <div class="step-bar-right"></div>
                        </div>
                        <div class="step">
                            <div class="step-circle"><span>3</span></div>
                            <div class="step-bar-left"></div>
                            <div class="step-bar-right"></div>
                        </div>
                        <div class="step">
                            <div class="step-circle"><span>4</span></div>
                            <div class="step-bar-left"></div>
                            <div class="step-bar-right"></div>
                        </div>
                    </div>

                    <div class="tab">
                        <button class="tablinks active" onclick="openCity(event, 'Step1')">Step 1</button>
                        <button class="tablinks" onclick="openCity(event, 'Step2')">Step 2</button>
                        <button class="tablinks" onclick="openCity(event, 'Step3')">Step 3</button>
                        <button class="tablinks" onclick="openCity(event, 'Step4')">Step 4</button>
                    </div>
                    <form action="" id="divQuestionnaireForm">
                        <div class="card card_design">
                            <div id="Step1" class="tabcontent pagination_one">

                            </div>
                            <div id="Step2" class="tabcontent pagination_two">

                            </div>

                            <div id="Step3" class="tabcontent pagination_three">

                            </div>
                            <div id="Step4" class="tabcontent pagination_four">

                            </div>
                            <!-- <ul id="pagin"></ul> -->
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="tile-footer title-footer-button-alignment">
            <button class="btn btn-primary saveButton_form" type="button" id="saveButton">
                <i class="fa fa-fw fa-lg fa-check-circle"></i>Save</button>&nbsp;&nbsp;&nbsp;
            <a class="btn btn-secondary" href=""><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
        </div>
        <div class="bs-stepper-content">
            <div id="test-l-1" class="content">
                <button class="btn btn-primary" onclick="nextStep()">Next</button>
            </div>
        </div>
    </div>
</div>
<script>
    $('#saveButton').click(function() {
        $('#saveButton').attr("disabled", true);
        var dataForm = $('form#divQuestionnaireForm').serializeArray();
        var formData = {};
        for (var i = 0; i < dataForm.length; i++) {
            formData[dataForm[i].name] = dataForm[i].value;
        }
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
            url: '/questionnaire/form/save',
            type: 'POST',
            data: {
                _token: CSRF_TOKEN,
                formData
            }
        }).done(function(data) {
            // alert('success');
        });
    });
</script>
<script>
    var stepper1Node = document.querySelector('#stepper1')
    var stepper1 = new Stepper(document.querySelector('#stepper1'))

    stepper1Node.addEventListener('show.bs-stepper', function(event) {
        console.warn('show.bs-stepper', event)
    })
    stepper1Node.addEventListener('shown.bs-stepper', function(event) {
        console.warn('shown.bs-stepper', event)
    })

    var stepper2 = new Stepper(document.querySelector('#stepper2'), {
        linear: false,
        animation: true
    })
    var stepper3 = new Stepper(document.querySelector('#stepper3'), {
        animation: true
    })
    var stepper4 = new Stepper(document.querySelector('#stepper4'))
</script>
<script>
    $(document).ready(function() {
        var cityName = 'Step1';
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    });

    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script>
    var currentStep = 1;
    var numSteps = 4;

    function nextStep() {


        $('.pagination' + currentStep + '').each(function(i, el) {
            var type = $(el).attr('type');
            var name = $(el).attr('name');
            if (type == 'text') {
                var data = $(el).val();
                if (data == '' || data == null || data == undefined) {


                    var i, tabcontent, tablinks;
                    var cityName = 'Step'.concat(currentStep++);
                    tabcontent = document.getElementsByClassName("tabcontent");
                    for (i = 0; i < tabcontent.length; i++) {
                        tabcontent[i].style.display = "none";
                    }
                    tablinks = document.getElementsByClassName("tablinks");
                    for (i = 0; i < tablinks.length; i++) {
                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                    }
                    document.getElementById(cityName).style.display = "block";
                    document.getElementById(cityName).classList.add('active');
                    

                    // openCity();
                    // var currentName = '#Step'.concat(currentStep);//alert(cityName);
                    // var cityName = '#Step'.concat(currentStep++);//alert(cityName);
                    // document.getElementById(cityName).style.display = "block";
                    // jQuery(currentName).removeClass('active');
                    // jQuery(cityName).addClass('active');
                    return false;
                } else {
                    currentStep++;
                    if (currentStep > numSteps) {
                        currentStep = 1;
                    }
                    var stepper = document.getElementById('stepper1');
                    var steps = stepper.getElementsByClassName('step');

                    Array.from(steps).forEach((step, index) => {
                        let stepNum = index + 1;
                        if (stepNum === currentStep) {
                            addClass(step, 'editing');
                        } else {
                            removeClass(step, 'editing');
                        }
                        if (stepNum < currentStep) {
                            addClass(step, 'done');
                        } else {
                            removeClass(step, 'done');
                        }
                    })
                }
            } else {
                var radios = document.getElementsByName(name);
                var getSelectedValue = document.querySelector("input[name=" + name + "]:checked").value;
                if (getSelectedValue == null) {
                    return false;
                } else {
                    currentStep++;
                    if (currentStep > numSteps) {
                        currentStep = 1;
                    }
                    var stepper = document.getElementById('stepper1');
                    var steps = stepper.getElementsByClassName('step');

                    Array.from(steps).forEach((step, index) => {
                        let stepNum = index + 1;
                        if (stepNum === currentStep) {
                            addClass(step, 'editing');
                        } else {
                            removeClass(step, 'editing');
                        }
                        if (stepNum < currentStep) {
                            addClass(step, 'done');
                        } else {
                            removeClass(step, 'done');
                        }
                    })
                }
            }
        });
    }


    /* get, set class, see https://ultimatecourses.com/blog/javascript-hasclass-addclass-removeclass-toggleclass */

    function hasClass(elem, className) {
        return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
    }

    function addClass(elem, className) {
        if (!hasClass(elem, className)) {
            elem.className += ' ' + className;
        }
    }

    function removeClass(elem, className) {
        var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, ' ') + ' ';
        if (hasClass(elem, className)) {
            while (newClass.indexOf(' ' + className + ' ') >= 0) {
                newClass = newClass.replace(' ' + className + ' ', ' ');
            }
            elem.className = newClass.replace(/^\s+|\s+$/g, '');
        }
    }
</script>

<script>
    // $(document).ready(function() {
    //     var questionnaireID = $('#questionnaireID').val();
    //     $.ajax({
    //         url: '/questionnaire/fields/list',
    //         type: 'GET',
    //         data: {
    //             'questionnaireID': questionnaireID
    //         }
    //     }).done(function(data) {
    //         var response = JSON.parse(data);
    //         console.log(response);
    //         if (response.length > 0) {
    //             QuestionnaireForm(response);
    //             pagination();
    //         }
    //         $(".loader_div").hide();
    //     })
    // });


    $(document).ready(function() {

        var response = <?php echo (json_encode($question)); ?>;
        if (response.length > 0) {
            QuestionnaireForm(response);
            // pagination();
            pagi_nation();
        }

    });

    // function autoIncrementCustomId(lastRecordId) {
    //     let increasedNum = Number(lastRecordId.replace('#Step', '')) + 1;
    //     let kmsStr = lastRecordId.substr(0, 5);
    //     kmsStr = kmsStr + increasedNum.toString();
    //     return kmsStr;
    // }

    function QuestionnaireForm(DataFields) {
        var count = DataFields.length;
        var tab_count = Math.ceil(count / 4);

        const tab_content = [0];
        for (i = 1; i <= 4; i++) {
            tab_content.push(i * tab_count - 1);
        }
        // alert(tab_content);
        var step = '#Step';
        let num = 0;

        var documentCategoryID = $('#documentCategory').val();
        for (let index = 0; index < DataFields.length; index++) {

            const isInArray = tab_content.includes(index);
            if (isInArray == true) {
                num++
                const stage1 = step.concat(num);
                var stage = step.concat(num);
            }
            // stage = '#Step1';

            const fieldTypeID = DataFields[index]['questionnaire_field_types_id'];
            const fieldID = DataFields[index]['question_details_id'];
            const fieldLabel = DataFields[index]['question'];
            const fieldName = DataFields[index]['question_field_name'];

            if (fieldTypeID == 1) {
                var textboxHtml = '<div class="col-md-6"><div class="form-group pagination-element' + num + '">';
                textboxHtml += '<label class="control-label">' + fieldLabel + '</label>';
                textboxHtml += '<input class="form-control pagination' + num + '" type="text" id="' + fieldName + '" name="' + fieldName + '" placeholder="Enter ' + fieldLabel + '">';
                textboxHtml += '</div></div>';
                $(stage).append(textboxHtml);
            }

            if (fieldTypeID == 2) {
                var textboxHtml = '<div class="col-md-6"><div class="form-group pagination-element' + num + '">';
                textboxHtml += '<label class="control-label">' + fieldLabel + '</label>';
                // textboxHtml += '<input class="form-control" type="text" id="' + fieldName + '" name="' + fieldName + '" placeholder="Enter ' + fieldLabel + '">';
                textboxHtml += '<textarea class="form-control pagination' + num + '" id="' + fieldName + '" name="' + fieldName + '" rows="2" cols="25"></textarea>';
                textboxHtml += '</div></div>';
                $(stage).append(textboxHtml);
            }

            if (fieldTypeID == 3) {
                $.ajax({
                    url: '/questionnaire/field/dropdown/option',
                    type: 'GET',
                    async: false,
                    data: {
                        fieldID: fieldID,
                        _token: '{{csrf_token()}}'
                    }
                }).done(function(data) {
                    var response = JSON.parse(data);
                    var dropdownHtml = '<div class="col-md-6"><div class="form-group pagination-element' + num + '">';
                    dropdownHtml += '<label class="control-label">' + fieldLabel + '</label>';
                    dropdownHtml += '<select class="form-control documentCategory pagination' + num + '" name="' + fieldName + '" id="' + fieldName + '">';
                    dropdownHtml += '<option value="">---Select ' + fieldLabel + '---</option>';
                    for (let index = 0; index < response.length; index++) {
                        const question_details_id = response[index]['question_details_id'];
                        const option_field_name = response[index]['option_for_question'];
                        if (question_details_id == fieldID)
                            var option = "<option value='" + option_field_name + "'>" + option_field_name + "</option>";
                        dropdownHtml += option;
                    }
                    dropdownHtml += '</select></div></div>';
                    $(stage).append(dropdownHtml);
                });
            }

            if (fieldTypeID == 4) {
                $.ajax({
                    url: '/questionnaire/field/dropdown/option',
                    type: 'GET',
                    async: false,
                    data: {
                        fieldID: fieldID,
                        _token: '{{csrf_token()}}'
                    }
                }).done(function(data) {
                    var response = JSON.parse(data);
                    var radioButtonHtml = '<div class="col-md-8"><div class="form-group pagination-element' + num + '">';
                    radioButtonHtml += '<label class="control-label">' + fieldLabel + '</label>';
                    for (let index = 0; index < response.length; index++) {
                        const question_details_id = response[index]['question_details_id'];
                        const option_field_name = response[index]['option_for_question'];
                        if (question_details_id == fieldID)
                            radioButtonHtml += '<input class="pagination' + num + '" type="radio" name="' + fieldName + '" id="' + fieldName + '" value="' + option_field_name + '">' + option_field_name;
                    }
                    radioButtonHtml += '</div></div>';
                    $(stage).append(radioButtonHtml);
                });
            }

            if (fieldTypeID == 5) {
                $.ajax({
                    url: '/questionnaire/field/dropdown/option',
                    type: 'GET',
                    async: false,
                    data: {
                        fieldID: fieldID,
                        _token: '{{csrf_token()}}'
                    }
                }).done(function(data) {
                    var response = JSON.parse(data);
                    var radioButtonHtml = '<div class="col-md-8"><div class="form-group pagination-element' + num + '">';
                    radioButtonHtml += '<label class="control-label">' + fieldLabel + '</label>';
                    for (let index = 0; index < response.length; index++) {
                        const question_details_id = response[index]['question_details_id'];
                        const option_field_name = response[index]['option_for_question'];
                        if (question_details_id == fieldID)
                            radioButtonHtml += '<input class="pagination' + num + '" type="checkbox" name="' + fieldName + '" id="' + fieldName + '" value="' + option_field_name + '">' + option_field_name;
                    }
                    radioButtonHtml += '</div></div>';
                    $(stage).append(radioButtonHtml);
                });
            }

            if (fieldTypeID == 7) {
                $.ajax({
                    url: '/questionnaire/field/subradio/option',
                    type: 'GET',
                    async: false,
                    data: {
                        fieldID: fieldID,
                        _token: '{{csrf_token()}}'
                    }
                }).done(function(data) {
                    var response = JSON.parse(data);
                    var fieldOptions = response.fieldOptions;
                    var fieldQuestions = response.fieldQuestions;
                    var radioButtonHtml = '<div class="col-md-12"><div class="form-group pagination-element' + num + '">';
                    radioButtonHtml += '<label class="control-label">' + fieldLabel + '</label><br>'; //Sub Question Radio
                    radioButtonHtml += '<table class="table_content">';
                    radioButtonHtml += '<tr>';
                    radioButtonHtml += '<th></th>';
                    for (let index = 0; index < fieldOptions.length; index++) {
                        const question_details_id = fieldOptions[index]['question_details_id'];
                        const option_field_name = fieldOptions[index]['option_for_question'];
                        if (question_details_id == fieldID)
                            // radioButtonHtml += '<label class="control-label q_lable">' + option_field_name + '</label>';
                            radioButtonHtml += '<th>' + option_field_name + '</th>';
                    }
                    radioButtonHtml += '</tr>';
                    radioButtonHtml += '<tr>';
                    for (let i = 0; i < fieldQuestions.length; i++) {
                        const sub_questions_id = fieldQuestions[i]['sub_questions_id'];
                        const sub_question = fieldQuestions[i]['sub_question'];
                        // radioButtonHtml += '<div>'
                        radioButtonHtml += '<td>' + sub_question + '</td>';
                        for (let index = 0; index < fieldOptions.length; index++) {
                            const question_details_id = fieldOptions[index]['question_details_id'];
                            const option_field_name = fieldOptions[index]['option_for_question'];
                            if (question_details_id == fieldID)
                                radioButtonHtml += '<td><input class="pagination' + num + '" type="radio" name="' + fieldName + sub_questions_id + '" id="' + fieldName + sub_questions_id + '" value="' + option_field_name + sub_questions_id + '"></td>';
                        }
                        radioButtonHtml += '</tr>'
                    }
                    radioButtonHtml += '</table>';
                    $(stage).append(radioButtonHtml);
                });
            }
        }
    }
</script>
<!-- <style>
    .option_lable {
        max-width: 7%;
    }

    #pagin {
        margin: 0;
        padding: 0;
        text-align: center
    }

    #pagin li {
        display: inline
    }

    #pagin li a {
        display: inline-block;
        text-decoration: none;
        padding: 5px 10px;
        color: #000
    }

    #pagin li a {
        border-radius: 5px;
        -webkit-transition: background-color 0.3s;
        transition: background-color 0.3s
    }

    #pagin li a.current {
        background-color: #4caf50;
        color: #fff
    }

    #pagin li a:hover:not(.current) {
        background-color: #ddd;
    }


    .pagination ul {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        background: #fff;
        padding: 8px;
        border-radius: 50px;
        box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.1);
    }

    .pagination ul li {
        color: #20B2AA;
        list-style: none;
        line-height: 45px;
        text-align: center;
        font-size: 18px;
        font-weight: 500;
        cursor: pointer;
        user-select: none;
        transition: all 0.3s ease;
    }

    .pagination ul li.numb {
        list-style: none;
        height: 45px;
        width: 45px;
        margin: 0 3px;
        line-height: 45px;
        border-radius: 50%;
    }

    .pagination ul li.numb.first {
        margin: 0px 3px 0 -5px;
    }

    .pagination ul li.numb.last {
        margin: 0px -5px 0 3px;
    }

    .pagination ul li.dots {
        font-size: 22px;
        cursor: default;
    }

    .pagination ul li.btn {
        padding: 0 20px;
        border-radius: 50px;
    }

    .pagination li.active,
    .pagination ul li.numb:hover,
    .pagination ul li:first-child:hover,
    .pagination ul li:last-child:hover {
        color: #fff;
        background: #20B2AA;
    }
</style> -->
<style>
    .pagination {
        padding: 20px;
    }

    .pagination,
    .pagination * {
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    .pagination a {
        display: inline-block;
        padding: 0 10px;
        cursor: pointer;
    }

    .pagination a.disabled {
        opacity: 0.3;
        pointer-events: none;
        cursor: not-allowed;
    }

    .pagination a.current {
        background: #f3f3f3;
    }
</style>
<script>
    function pagination() {
        //Pagination
        pageSize = 4;
        incremSlide = 5;
        startPage = 0;
        numberPage = 0;

        var pageCount = $(".pagination-element").length / pageSize;
        var totalSlidepPage = Math.floor(pageCount / incremSlide);

        for (var i = 0; i < pageCount; i++) {
            $("#pagin").append('<li><a href="#">' + (i + 1) + '</a></li> ');
            if (i > pageSize) {
                $("#pagin li").eq(i).hide();
            }
        }

        var prev = $("<li/>").addClass("prev").html("Prev").click(function() {
            startPage -= 1;
            incremSlide -= 1;
            numberPage--;
            slide();
        });

        prev.hide();

        var next = $("<li/>").addClass("next").html("Next").click(function() {
            startPage += 1;
            incremSlide += 1;
            numberPage++;
            slide();
        });

        $("#pagin").prepend(prev).append(next);

        $("#pagin li").first().find("a").addClass("current");

        slide = function(sens) {
            $("#pagin li").hide();

            for (t = startPage; t < incremSlide; t++) {
                $("#pagin li").eq(t + 1).show();
            }
            if (startPage == 0) {
                next.show();
                prev.hide();
            } else if (numberPage == totalSlidepPage) {
                next.hide();
                prev.show();
            } else {
                next.show();
                prev.show();
            }
        }

        showPage = function(page) {
            $(".pagination-element").hide();
            $(".pagination-element").each(function(n) {
                if (n >= pageSize * (page - 1) && n < pageSize * page)
                    $(this).show();
            });
        }

        showPage(1);
        $("#pagin li a").eq(0).addClass("current");

        $("#pagin li a").click(function() {
            $("#pagin li a").removeClass("current");
            $(this).addClass("current");
            showPage(parseInt($(this).text()));
        });
    }

    function pagi_nation() {
        // (function($) {
        var pagify = {
            items: {},
            container: null,
            totalPages: 1,
            perPage: 3,
            currentPage: 0,
            createNavigation: function() {
                this.totalPages = Math.ceil(this.items.length / this.perPage);

                $('.pagination', this.container.parent()).remove();
                var pagination = $('<div class="pagination"></div>').append('<a class="nav prev disabled" data-next="false"><</a>');

                for (var i = 0; i < this.totalPages; i++) {
                    var pageElClass = "page";
                    if (!i)
                        pageElClass = "page current";
                    var pageEl = '<a class="' + pageElClass + '" data-page="' + (
                        i + 1) + '">' + (
                        i + 1) + "</a>";
                    pagination.append(pageEl);
                }
                pagination.append('<a class="nav next" data-next="true">></a>');

                this.container.after(pagination);

                var that = this;
                $("body").off("click", ".nav");
                this.navigator = $("body").on("click", ".nav", function() {
                    var el = $(this);
                    that.navigate(el.data("next"));
                });

                $("body").off("click", ".page");
                this.pageNavigator = $("body").on("click", ".page", function() {
                    var el = $(this);
                    that.goToPage(el.data("page"));
                });
            },
            navigate: function(next) {
                // default perPage to 5
                if (isNaN(next) || next === undefined) {
                    next = true;
                }
                $(".pagination .nav").removeClass("disabled");
                if (next) {
                    this.currentPage++;
                    if (this.currentPage > (this.totalPages - 1))
                        this.currentPage = (this.totalPages - 1);
                    if (this.currentPage == (this.totalPages - 1))
                        $(".pagination .nav.next").addClass("disabled");
                } else {
                    this.currentPage--;
                    if (this.currentPage < 0)
                        this.currentPage = 0;
                    if (this.currentPage == 0)
                        $(".pagination .nav.prev").addClass("disabled");
                }

                this.showItems();
            },
            updateNavigation: function() {

                var pages = $(".pagination .page");
                pages.removeClass("current");
                $('.pagination .page[data-page="' + (
                    this.currentPage + 1) + '"]').addClass("current");
            },
            goToPage: function(page) {

                this.currentPage = page - 1;

                $(".pagination .nav").removeClass("disabled");
                if (this.currentPage == (this.totalPages - 1))
                    $(".pagination .nav.next").addClass("disabled");

                if (this.currentPage == 0)
                    $(".pagination .nav.prev").addClass("disabled");
                this.showItems();
            },
            showItems: function() {
                this.items.hide();
                var base = this.perPage * this.currentPage;
                this.items.slice(base, base + this.perPage).show();

                this.updateNavigation();
            },
            init: function(container, items, perPage, index) {
                this.container = container;
                this.currentPage = 0;
                this.totalPages = 1;
                this.perPage = perPage;
                this.items = items;
                this.index = index;
                this.createNavigation();
                this.showItems();
            }
        };

        // stuff it all into a jQuery method!
        $.fn.pagify = function(perPage, itemSelector, index) {
            // alert(index);
            var el = $(this);
            var items = $(itemSelector, el);

            // default perPage to 5
            if (isNaN(perPage) || perPage === undefined) {
                perPage = 3;
            }

            // don't fire if fewer items than perPage
            if (items.length <= perPage) {
                return true;
            }

            pagify.init(el, items, perPage, index);
        };
        // })(jQuery);

        // for(i=1;i <= 4;i++){
        $(".pagination_one").pagify(6, ".pagination-element1", 1);
        $(".pagination_two").pagify(6, ".pagination-element2", 2);
        $(".pagination_three").pagify(6, ".pagination-element3", 3);
        $(".pagination_four").pagify(6, ".pagination-element4", 4);
        // }

    }
</script>
@endsection