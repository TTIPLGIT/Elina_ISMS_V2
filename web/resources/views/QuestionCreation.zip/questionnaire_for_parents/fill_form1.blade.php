<div id="tab-container" class="tab-container">
  <div class="container-fluid">
    <div class="text-center col-md-10 col-md-offset-1">

      <input id="tab1" type="radio" name="tabs" checked>
      <label for="tab1">Tab one</label>

      <input id="tab2" type="radio" name="tabs">
      <label for="tab2">Tab two</label>

      <input id="tab3" type="radio" name="tabs">
      <label for="tab3">Tab three</label>

      <input id="tab4" type="radio" name="tabs">
      <label for="tab4">Tab four</label>

      <div id="content1" class="tab-content">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
              <div class="card card-body">
                <div class="view">
                  <img src="https://assets.foxdcg.com/dpp-uploaded/images/the-90s-greatest/seriesDetail.jpg?fit=inside%7C1920:1080" class="img-responsive" alt="">
                </div>
                <div class="card text-center">
                  <h4 class="card-title"><strong>Name</strong></h4>
                  <p class="card-description">Some informations <br>
                    will be placed here
                  </p>
                  <a href="#!" class="card-link">See more
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div id="content2" class="tab-content">
        <p>
          Pudding ice cream croissant toffee muffin biscuit.
        </p>
      </div>

      <div id="content3" class="tab-content">
        <p>
          Marshmallow soufflé sweet cake. Sweet lollipop jujubes marshmallow gummi bears cotton candy topping cheesecake marshmallow.
        </p>
      </div>

      <div id="content4" class="tab-content">
        <p>
          Pastry carrot cake jelly-o. Sugar plum caramels croissant.
        </p>
      </div>

    </div>
  </div>
</div>