@extends('layouts.adminnav')

@section('content')

<style>
    input[type=checkbox] {
        display: inline-block;

    }

    .no-arrow {
        -moz-appearance: textfield;
    }

    .no-arrow::-webkit-inner-spin-button {
        display: none;
    }

    .no-arrow::-webkit-outer-spin-button,
    .no-arrow::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* body{
        background-color: white !important;
    } */
    .nav-tabs {
        background-color: #0068a7 !important;
        border-radius: 29px !important;
        padding: 1px !important;

    }

    .nav-item.active {
        background-color: #0e2381 !important;
        border-radius: 31px !important;
        height: 100% !important;
    }

    .nav-link.active {
        background-color: #0e2381 !important;
        border-radius: 31px !important;
        height: 100% !important;
    }

    .nav-justified {
        display: flex !important;
        align-items: center !important;
    }

    hr {
        border-top: 1px solid #6c757d !important;
    }

    .dateformat {
        height: 41px;
        padding: 8px 10px !important;
        width: 100%;
        border-radius: 5px !important;
        border-color: #bec4d0 !important;
        box-shadow: 2px 2px 4px rgb(0 0 0 / 15%);
        border-style: outset;
    }

    h4 {
        text-align: center;
    }

    .question {
        background-color: white;
        border-radius: 12px !important;
        margin-top: 2rem;
    }

    .question label {
        text-align: center;
    }

    .questionnaire {
        text-align: center;
    }

    .btn-success {
        margin: auto;
    }
</style>
<div class="main-content">

    <div class="section-body mt-0">
        <h4> Questionaire Creation </h4>



        <div class="card question">
            <div class="row" style="margin-bottom: 15px;margin-top: 20px;">

                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <label class="control-label">Questionaire Name</label>
                        <select class="form-control" name="questionnaire_id" id="questionnaire_id">
                            <option value="">select Questionnaire</option>
                            @foreach($questionnaire_list as $data)
                            <option value="{{$data['questionnaire_id']}}">{{$data['questionnaire_name']}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <label class="control-label">Discription</label>
                        <textarea class="form-control" type="text" id="discription" name="discription" placeholder="" autocomplete="off"> </textarea>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <label class="control-label">No.Of.Questions</label>
                        <input class="form-control" type="number" id="no_of_ques" name="no_of_ques" autocomplete="off">
                    </div>
                </div>
                <button type="button" class="btn btn-success" id="saveButton">Save</button>
            </div>
        </div>




        <div class="card question" id="next-section" style="display: none;">
            <div class="row" style="margin-bottom: 15px;margin-top: 20px;">

                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <label class="control-label">Question type</label>
                        <select class="form-control" name="option-tab" id="option-tab" onChange="typechange()">
                            <option value="">select Question type</option>
                            <option value="textbox">Textbox</option>
                            <option value="textarea">Textarea</option>
                            <option value="dropdown">Dropdown</option>
                            <option value="radobutton">Radio button</option>
                            <option value="checkbox">check box</option>
                            <option value="sub-dropdown">Subquestion-dropdown</option>
                            <option value="sub-radiobutton">Subquestion-Radio button</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group questionnaire">
                        <label class="control-label">Questions</label>
                        <input class="form-control" type="" id="" name="" maxlength="" value="" placeholder="" autocomplete="off">
                    </div>
                </div>
                <div class="col-4" style="display: none;" id="option">
                    <div class="form-group">
                        <label>Option</label>
                        <div class="multi-field-wrapper">
                            <div class="multi-fields">
                                <div class="multi-field" style="display: flex;margin-bottom: 5px;">

                                    <input type="text" class="form-control" name="" id="question_discription[]">
                                    <button class="remove-field btn btn-danger pull-right" id="remove-f" type='button'>X </button>
                                    <button class="add-field btn btn-danger pull-right" id="" type='button'>+ </button>
                                    &nbsp;
                                </div>
                            </div>
                            <!-- <button type="button" class="add-field btn btn-success">Add Option</button> -->
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group" style="display:none">
                        <label class="control-label"> subquestions</label>
                        <input class="form-control" type="number" id="" name="" maxlength="" value="" placeholder="" autocomplete="off">
                    </div>
                </div>
                <button type="button" class="btn btn-success">Save</button>
            </div>
        </div>

        </section>

    </div>
</div>

<script>
    $("#saveButton").click(function(event) {
        event.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var questionnaire_id = document.getElementById("questionnaire_id").value;
        if (questionnaire_id == null || questionnaire_id == "") {
            swal("Please Select Questionnaire Name: ", "", "error");
            return false;
        }
        
        var discription = document.getElementById("discription").value;
        if (discription == null || discription == '') {
            swal("Please Discription", "", "error");
            return false;
        }

        var no_of_ques = document.getElementById("no_of_ques").value;
        if (no_of_ques == '' || no_of_ques == null) {
            swal("Please Enter No Of Questions", "", "error");
            return false;
        }

        $('#saveButton').prop('disabled', true);
      
        $.ajax({
            url: '{{ url('/question_creation/store_data') }}',
            type: "POST",
            data: {
                _token: '{{csrf_token()}}',
                questionnaire_id: questionnaire_id,
                discription: discription,
                no_of_ques: no_of_ques,
            },

            success: function(data) {
			    window.location.href = "/question_creation/add_questions/"+data;

                // if (data != null) {
                //     swal({
                //             title: "Initiated",
                //             text: "Question Created Successfully",
                //             type: "success",
                //             confirmButtonColor: '#e73131',
                //             confirmButtonText: 'OK',
                //         },
                //         function(isConfirm) {
                //             if (isConfirm) {
				// 			    window.location.href = "/question_creation/add_questions/"+data;
                //             } else {

                //             }
                //         });

                // }


            },
            error: function(data) {
                swal({
                        title: "Error",
                        text: data,
                        type: "error",
                        confirmButtonColor: '#e73131',
                        confirmButtonText: 'OK',
                    },
                    function(isConfirm) {
                        if (isConfirm) {
                            location.reload();
                        } else {

                        }
                    });

                console.log(data);
            }
        });

    });
</script>
<script>
    function newsection() {
        document.getElementById('next-section').style.display = "block";

    }
</script>
<script type="text/javascript">
    $('.multi-field-wrapper').each(function() {
        var $wrapper = $('.multi-fields', this);
        $(".add-field", $(this)).click(function(e) {
            $('.multi-field:first-child', $wrapper).clone(true).appendTo($wrapper).find('input').val('').focus();
        });
        $('.multi-field .remove-field', $wrapper).click(function() {
            if ($('.multi-field', $wrapper).length > 2)
                $(this).parent('.multi-field').remove();
            else bootbox.alert({
                title: "Metadata creation",
                centerVertical: true,
                message: "Required Two Dropdown Option",
            });
        });
    });
</script>

<script type="text/javascript">
    function typeChange() {
        var fieldtype = $('#option-tab').val();
        alert("hi");
        if (fieldtype == dropdown) {
            $('#option').hide();
        } else {
            $('#option').show();
        }
    }
</script>

@endsection