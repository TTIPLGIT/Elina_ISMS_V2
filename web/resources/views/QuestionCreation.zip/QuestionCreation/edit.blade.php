@foreach($question_details as $data)
<div class="modal fade" id="editmodulemodal{{$data['question_details_id']}}">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <form name="edit_form" action="{{ route('question_creation.update', \Crypt::encrypt($data['question_details_id'])) }}" method="POST" id="edit_question_form{{$data['question_details_id']}}">
        {{ csrf_field() }}
        @method('PUT')
        <div class="modal-header" style="background-color:DarkSlateBlue;">
          <h5 class="modal-title" id="#editModal">Edit Question</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row register-form">


            <div class="row" style="margin-bottom: 15px;margin-top: 20px;">

              <div class="col-md-12">
                <div class="form-group questionnaire">
                  <label class="control-label">Questions</label>
                  <input class="form-control" type="text" id="field_question" name="field_question" value="{{$data['question']}}" autocomplete="off">
                </div>
              </div>
              <input type="hidden" name="client_data" value="{{$questionnaire_list[0]['questionnaire_details_id']}}">
              <input type="hidden" value="{{$data['questionnaire_field_types_id']}}" name="edit_field_types_id" id="edit_field_types_id">

              <div class="col-12" style="display: none;" id="edit_option{{$data['question_details_id']}}">
                <div class="form-group">
                  <label>Option</label>
                  <div class="multi-field-wrapper">
                    <div class="multi-fields">
                      @foreach($option_question_fields as $data1)
                      @if($data['question_details_id'] == $data1['question_details_id'])
                      <div class="multi-field" style="display: flex;margin-bottom: 5px;">
                        <input type="text" value="{{$data1['option_for_question']}}" class="form-control" name="options_question[]" id="options_question[]">
                        <button class="remove-field btn btn-danger pull-right" id="remove-f" type='button'>X </button>
                        <!-- <button class="add-field btn btn-danger pull-right" id="" type='button'>+ </button> -->
                        &nbsp;
                      </div>
                      @endif
                      @endforeach
                    </div>
                    <!-- <button class="add-field btn btn-danger" id="" type='button'>+ </button> -->
                    <button type="button" class="add-field btn btn-success">Add Option</button>
                  </div>
                </div>
              </div>

              <div class="w-100"></div>

              <div class="row" style="display: none;" id="edit_sub_questions{{$data['question_details_id']}}">
                <div class="col-6">
                  <div class="form-group">
                    <label>Sub Question</label>
                    <div class="multi-field-wrapper">
                      <div class="multi-fields">
                        @foreach($sub_questions as $data2)
                        @if($data['question_details_id'] == $data2['question_details_id'])
                        <div class="multi-field" style="display: flex;margin-bottom: 5px;">

                          <input type="text" value="{{$data2['sub_question']}}" class="form-control" name="sub_questions[]" id="sub_questions[]">
                          <button class="remove-field btn btn-danger pull-right" id="remove-f" type='button'>X </button>
                          <!-- <button class="add-field btn btn-danger pull-right" id="" type='button'>+ </button> -->
                          &nbsp;
                        </div>
                        @endif
                        @endforeach
                      </div>
                      <button type="button" class="add-field btn btn-success">Add Question</button>
                    </div>
                  </div>
                </div>

                <div class="col-12" >
                  <div class="form-group">
                    <label>Option</label>
                    <div class="multi-field-wrapper">
                      <div class="multi-fields">
                        @foreach($option_question_fields as $data1)
                        @if($data['question_details_id'] == $data1['question_details_id'])
                        <div class="multi-field" style="display: flex;margin-bottom: 5px;">
                          <input type="text" value="{{$data1['option_for_question']}}" class="form-control" name="sub_options[]" id="sub_options[]">
                          <button class="remove-field btn btn-danger pull-right" id="remove-f" type='button'>X </button>
                          <!-- <button class="add-field btn btn-danger pull-right" id="" type='button'>+ </button> -->
                          &nbsp;
                        </div>
                        @endif
                        @endforeach
                      </div>
                      <!-- <button class="add-field btn btn-danger" id="" type='button'>+ </button> -->
                      <button type="button" class="add-field btn btn-success">Add Option</button>
                    </div>
                  </div>
                </div>
              </div>

              <div class="w-100"></div>
            </div>


          </div>

          <div class="modal-footer">
            <div class="mx-auto">

              <a type="button" onclick="editbuttonclick('{{$data['question_details_id']}}')" class="btn btn-labeled btn-succes" title="Update" style="background: green !important; border-color:green !important; color:white !important">
                <span class="btn-label" style="font-size:13px !important;"><i class="fa fa-check"></i></span>Update</a>
              <a type="button" data-dismiss="modal" aria-label="Close" value="Cancel" class="btn btn-labeled btn-space" title="Cancel" style="background: red !important; border-color:red !important; color:white !important">
                <span class="btn-label" style="font-size:13px !important;"><i class="fa fa-remove"></i></span>Cancel</a>


            </div>
          </div>

      </form>

    </div>
  </div>
</div>
</div>

<script>
  function editbuttonclick(id) {
    document.getElementById('edit_question_form' + id).submit();
  }
</script>
@endforeach
